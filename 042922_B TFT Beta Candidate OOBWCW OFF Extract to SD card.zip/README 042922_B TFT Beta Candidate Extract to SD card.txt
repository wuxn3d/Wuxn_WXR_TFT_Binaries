29 April 2022
042822 1659 Panama
042922 0830 Panama

*************************************************************************************
*** REQUIRES INSTALLATION OF NEW MARLIN BITS: "Marlin Firmware Version 042722"    ***
*************************************************************************************

FIRMWARE_VERSION "Wuxn_TFT_BETA_0429"

Fixes filament runout menus
Improves messaging.  Blanks the Resume/Pause key during the filament change.
Runs very well without pressing the "OK" button on the Filament Runout message pop-up.
Runs ok when pressing the "OK" button but shows printingMenu screen which is a bit confusing during the delays.

Still need to get rid of the "OK" button without breaking other things that would need it.

Published as 042922 1659 Panama (but the real date was 042822)
Committed files
Created new branch

Deactivated the pause/resume key area during RunningM600 so if it is touched, even though it is blanked,
nothing will happen.

Include updated Wuxn calibration print gcode in the zip package.

Published as 042922A
committed files.

